#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from pynput import keyboard
import time


linear_speed = 0.2
angular_speed = 0.5


pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)


robot_active = False
start_time = 0
time_limit = 60
time_active = False


def log_motion(message):
    rospy.loginfo(message)


def on_press(key):
    global robot_active, start_time, time_active
    twist = Twist()

    try:
        if key.char == 'w':  # İleri hareket
            if not robot_active:
                rospy.loginfo("Robot ileri hareket ediyor.")
                robot_active = True
                time_active = True
                if not start_time:
                    start_time = time.time()
            twist.linear.x = linear_speed
        elif key.char == 's':  # Geri hareket
            if not robot_active:
                rospy.loginfo("Robot geriye hareket ediyor.")
                robot_active = True
                time_active = True
                if not start_time:
                    start_time = time.time()
            twist.linear.x = -linear_speed
        elif key.char == 'a':  # Sola dönüş
            if not robot_active:
                rospy.loginfo("Robot sola dönüyor.")
                robot_active = True
                time_active = True
                if not start_time:
                    start_time = time.time()
            twist.angular.z = angular_speed
        elif key.char == 'd':  # Sağa dönüş
            if not robot_active:
                rospy.loginfo("Robot sağa dönüyor.")
                robot_active = True
                time_active = True
                if not start_time:
                    start_time = time.time()
            twist.angular.z = -angular_speed
    except AttributeError:
        pass

    pub.publish(twist)


def on_release(key):
    global robot_active
    twist = Twist()

    if robot_active:
        rospy.loginfo("Robot stopped.")
        robot_active = False
    pub.publish(twist)

    # ESC ile çıkış
    if key == keyboard.Key.esc:
        return False


def time_check():
    global robot_active, time_active, start_time
    if time_active and robot_active:
        end_time = time.time()
        if end_time - start_time >= time_limit:
            rospy.loginfo("Zaman doldu.")
            twist = Twist()
            pub.publish(twist)
            robot_active = False
            time_active = False

if __name__ == '__main__':
    rospy.init_node('turtlebot_keyboard_control', anonymous=True)
    rospy.loginfo("Hareket etmek için W, A, S, D tuşlarını kullanın. Çıkmak için ESC'ye basın.")


    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    listener.start()


    rate = rospy.Rate(10) 
    while not rospy.is_shutdown():
        time_check()
        rate.sleep()

    listener.join()

